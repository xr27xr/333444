token = '1745110782:AAHW1GH4k-NkV04eSvi_EuNo_MgEu0JJco4' # توكن البوت
sudo = 1683102194 # ايديك
time = 3 # السلسيب